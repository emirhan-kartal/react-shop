import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { TextField, Button, Box, Grid } from '@mui/material';


interface FormValues {
    name: string;
    surname: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    town: string;
    postalCode: string;
}

const AddressForm: React.FC = () => {
    const { handleSubmit, control } = useForm<FormValues>({
        defaultValues: {
            name: '',
            surname: '',
            address1: '',
            address2: '',
            city: '',
            state: '',
            town: '',
            postalCode: '',
        },
    });

    const onSubmit = (data: FormValues) => {
        console.log(data);
    };

    return (
        <Box
            component="form"
            onSubmit={handleSubmit(onSubmit)}
            sx={{ mt: 2 }}
        >
            <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                    <Controller
                        name="name"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="Name"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                    />
                </Grid>
                <Grid item xs={12} sm={6}>
                    <Controller
                        name="surname"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="Surname"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                    />
                </Grid>
                <Grid item xs={12}>
                    <Controller
                        name="address1"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="Address 1"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                    />
                </Grid>
                <Grid item xs={12}>
                    <Controller
                        name="address2"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="Address 2"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                    />
                </Grid>
                <Grid item xs={12} sm={4}>
                    <Controller
                        name="city"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="City"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                    />
                </Grid>
                <Grid item xs={12} sm={4}>
                    <Controller
                        name="state"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="State"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                    />
                </Grid>
                <Grid item xs={12} sm={4}>
                    <Controller
                        name="town"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="Town"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                    />
                </Grid>
                <Grid item xs={12}>
                    <Controller
                        name="postalCode"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="Postal Code"
                                variant="outlined"
                                fullWidth
                            />
                        )}
                    />
                </Grid>
                <Grid item xs={12}>
                    <Button type="submit" variant="contained" color="primary">
                        Submit
                    </Button>
                </Grid>
            </Grid>
        </Box>
    );
};

export default AddressForm;
