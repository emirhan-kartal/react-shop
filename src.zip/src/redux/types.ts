import { ProductCardProps } from "../components/product/ProductCard";

type State = {

    cart: ProductCardProps[];
};
export type { State };
